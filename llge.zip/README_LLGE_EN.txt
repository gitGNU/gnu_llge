Libre Library of Graphic Elements
Libre library of graphic elements (hereinafter LLGE ) is a free library of graphic elements in the format *. Dxf program designed to LibreCAD.
LLGE contains conditional graphical notation of electronic circuits , block diagrams, electrical , relay protection , primary substation equipment and hatch patterns In accordance with national standards such as GOST , etc.
In the future we plan to supplement LLGE graphic elements and fonts other national standrtov , for example ANSI, and add standard hatch patterns .
In addition , it is planned to create a library consisting of c LLGE most common diagrams and drawings ( blocks of electrical circuits , etc.) , created using LibreCAD.

Acknowledgments .
I express my sincere appreciation and gratitude to the following persons:
kyzic
LibreCAD team
as well as all those who participated in the creation of fonts , frames and graphic components for LibreCAD.

Сontact the author:
﻿llge-support@yandex.ru
